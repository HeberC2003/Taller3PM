package com.example.testeableapp

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.*
import com.example.testeableapp.ui.Screens.TipCalculatorScreen
import org.junit.Rule
import org.junit.Test

class TipCalculatorUiTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun redondearPropina_actualizaCálculo() {
        //PARA Ingresar monto
        composeTestRule.onNodeWithText("Monto de la cuenta").performTextInput("100")

        // PARA Marcar checkbox "Redondear propina"
        composeTestRule.onNodeWithText("Redondear propina").performClick()

        // PARA Verificar que la propina mostrada es redondeada (por ejemplo, 15%)
        composeTestRule.onNodeWithText("Propina: $15.00").assertExists()
    }

    @Test
    fun cambiarSlider_actualizaPorcentajeYCalculo() {
        // Ingresar monto
        composeTestRule.onNodeWithText("Monto de la cuenta").performTextInput("100")

        // Mover el slider (por ejemplo al 20%)
        composeTestRule.onNodeWithTag("sliderTip").performTouchInput {
            // Cambiamos al 20% que es value 0.2 en 0..1
            swipeRight()
        }

        // Verificar que el texto del porcentaje cambió
        composeTestRule.onNodeWithText("Porcentaje de propina: 20%").assertExists()

        // Verificar que se muestra la propina correcta
        composeTestRule.onNodeWithText("Propina: $20.00").assertExists()
    }

    @Test
    fun elementosVisibles_enPantallaPrincipal() {
        // Verifica que el campo de monto esté presente
        composeTestRule.onNodeWithText("Monto de la cuenta").assertExists()

        // Verifica que el texto del porcentaje esté presente usando "substring = true"
        composeTestRule.onNodeWithText("Porcentaje de propina:", substring = true).assertExists()

        // Verifica que el texto de número de personas esté visible
        composeTestRule.onNodeWithText("Número de personas: 1").assertExists()
    }

    //TEST ADICIONALES

    @Test
    fun montoVacio_muestraPropinaCero() {
        // Campo vacío (por defecto)
        // Verificamos que la propina sea $0.00
        composeTestRule.onNodeWithText("Propina: $0.00").assertExists()
    }

    @Test
    fun disminuirNumeroPersonas_noPermiteMenorQueUno() {
        // Tocar el botón "-" varias veces
        repeat(3) {
            composeTestRule.onNodeWithText("-").performClick()
        }

        // Verificar que aún se muestra "1"
        composeTestRule.onNodeWithText("1").assertExists()
    }

}
