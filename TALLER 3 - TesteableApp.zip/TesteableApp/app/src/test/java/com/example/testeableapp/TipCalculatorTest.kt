package com.example.testeableapp

import org.junit.Test
import org.junit.Assert.assertEquals
import com.example.testeableapp.ui.Screens.calculateTip

class TipCalculatorTest {

    @Test
    fun calculoCon37PorcientoYRedondeo() {
        val result = calculateTip(100.0, 37, true)
        assertEquals(37.0, result, 0.0)
    }

    @Test
    fun montoNegativoDebeDevolverCero() {
        val result = calculateTip(-50.0, 15, false)
        assertEquals(0.0, result, 0.0)
    }

    @Test
    fun totalPorPersonaCon200_20porciento_4personas() {
        val bill = 200.0
        val tip = calculateTip(bill, 20, false)
        val totalPerPerson = (bill + tip) / 4
        assertEquals(60.0, totalPerPerson, 0.01)
    }

    //Adicionales

    @Test
    fun propinaCero_porcentajeCeroDebeDarCero() {
        val result = calculateTip(100.0, 0, false)
        assertEquals(0.0, result, 0.0)
    }

    @Test
    fun propinaAlta_montoGrandeCalculaCorrecto() {
        val result = calculateTip(9999.0, 10, false)
        assertEquals(999.9, result, 0.1)
    }

}

